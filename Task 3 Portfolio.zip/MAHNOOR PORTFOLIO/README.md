# Mahnoor Yasir Portfolio, Final Specific Links Version

Updates:
- Blue theme preserved.
- No overlap layout preserved.
- Specific GitHub and Itch.io links added for available Unity and web projects.
- Certificate cards now have View Certificate buttons.
- Certificate text uses commas instead of dash formatting.
- Resume file included in assets.
- Footer kept professional.

Note:
For certificates, the uploaded resume lists certificate names but does not expose individual verification URLs in visible text, so certificate buttons point to the LinkedIn certifications section instead of using fake or guessed links.
