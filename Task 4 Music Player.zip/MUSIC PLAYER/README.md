# CodeAlpha Music Player

A premium Spotify-style music player web application created for CodeAlpha Frontend Development Task 4.

## Features

- Play, pause, next, previous controls
- Song title, artist, genre, cover image, duration
- Progress bar and volume control
- Shuffle and repeat
- Autoplay next song
- Search songs by title or artist
- Artist categories
- Favorites playlist using localStorage
- Custom playlist using localStorage
- Recently played list
- Light and dark mode
- Keyboard shortcuts
- Toast notifications
- Responsive design

## Keyboard Shortcuts

- Space: Play/Pause
- Arrow Right: Next song
- Arrow Left: Previous song
- Arrow Up: Increase volume
- Arrow Down: Decrease volume

## Technologies

- HTML
- CSS
- JavaScript

## Note About Music

This project uses public demo MP3 files for frontend demonstration. Do not use copyrighted songs without permission.

## Created By

Mahnoor Yasir | CodeAlpha Frontend Development Internship
